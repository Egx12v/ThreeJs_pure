import { Component } from "react"
import { 
    Scene,
    WebGL1Renderer,
    PerspectiveCamera,
    Mesh,
    MeshBasicMaterial,
    BoxGeometry,
    SphereGeometry,
    TextureLoader,
    BackSide,
    MeshPhongMaterial,
    DirectionalLight,
    HemisphereLight,
    AmbientLight
} from "three"


const crearSkybox = (scene) => {
    const Skygeometry = new SphereGeometry(360, 25, 25)
    const loader = new TextureLoader()
    const textura = loader.load("/custom-sky.png")
    const material2 = new MeshPhongMaterial({
        map: textura
    })
    const skybox = new Mesh(Skygeometry, material2)
    skybox.material.side = BackSide
    scene.add(skybox)
}


export default class Background extends Component {
    componentDidMount(): void {
        const scene = new Scene()
        const renderer =  new WebGL1Renderer({
            antialias: true,
            canvas: document.getElementById("bg")
        })
        const camara = new PerspectiveCamera(
            50, 
            window.innerWidth /  window.innerHeight,
            0.1,
            1000
        )

        // mover camara
        camara.position.z = 6

        // crear cubo
        const geometria = new BoxGeometry(1,1,1)
        const material = new MeshBasicMaterial({ color: 0xffffff })
        const cubo = new Mesh(geometria, material)
        console.log(0xffffff)
        scene.add(cubo)

        // crear skybox
        crearSkybox(scene)

        // crear iluminacion
        scene.add(new AmbientLight(0xffffff, 0.8))
        scene.add(new HemisphereLight(0xffffff, 0.8))

        renderer.setSize(window.innerWidth, window.innerHeight)

        function animate() {
            cubo.rotation.x += 0.01
            cubo.rotation.y += 0.01

            renderer.render(scene, camara)
            requestAnimationFrame(animate)
        }
        animate()
    }


    render() {
        return <canvas id="bg" />
    }
}