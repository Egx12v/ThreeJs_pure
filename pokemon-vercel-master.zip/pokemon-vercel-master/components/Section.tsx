const Section = () => {
  return (
    <div>Section</div>
  )
}

export default Section